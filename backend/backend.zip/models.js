// // // const mongoose = require("mongoose");
// // // mongoose.connect("mongodb+srv://preetgupta0503:rlHh71e4aM6TgsDm@project1-db.wltp5.mongodb.net/?retryWrites=true&w=majority&appName=Project1-db")

// // // const ShoppingItemSchema = new mongoose.Schema({
// // //   name: { type: String, required: true },
// // //   category: { type: String },
// // //   quantity: { type: Number, default: 1 },
// // // });

// // // module.exports = mongoose.model("ShoppingItem", ShoppingItemSchema);


// // const mongoose = require("mongoose");
// // require("dotenv").config();

// // mongoose
// //   .connect(process.env.MONGO_URI, {
// //     useNewUrlParser: true,
// //     useUnifiedTopology: true,
// //   })
// //   .then(() => console.log("MongoDB connected successfully"))
// //   .catch((err) => console.error("MongoDB connection error:", err));

// // const ShoppingItemSchema = new mongoose.Schema({
// //   name: { type: String, required: true },
// //   category: { type: String },
// //   quantity: { type: Number, default: 1 },
// // });

// // module.exports = mongoose.model("ShoppingItem", ShoppingItemSchema);


// const mongoose = require("mongoose");
// require("dotenv").config();

// // MongoDB Connection
// mongoose
//   .connect(process.env.MONGO_URI, {
//     useNewUrlParser: true,
//     useUnifiedTopology: true,
//   })
//   .then(() => console.log("MongoDB connected successfully"))
//   .catch((err) => console.error("MongoDB connection error:", err));

// /* ========== PRODUCT SCHEMA ========== */
// // Stores available products
// const ProductSchema = new mongoose.Schema({
//   name: { type: String, required: true },
//   category: { type: String, required: true },
//   price: { type: Number, required: true },
//   expiryDate: { type: Date }, // Optional for perishable items
// });

// const Product = mongoose.model("Product", ProductSchema);

// /* ========== CART ITEM SCHEMA ========== */
// // Stores items added to the cart by users
// const CartItemSchema = new mongoose.Schema({
//   product: { type: mongoose.Schema.Types.ObjectId, ref: "Product", required: true },
//   quantity: { type: Number, default: 1 },
// });

// const CartItem = mongoose.model("CartItem", CartItemSchema);

// /* ========== SHOPPING LIST SCHEMA ========== */
// // Stores user's shopping lists
// const ShoppingListSchema = new mongoose.Schema({
//   userId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
//   items: [
//     {
//       product: { type: mongoose.Schema.Types.ObjectId, ref: "Product" },
//       quantity: { type: Number, default: 1 },
//     },
//   ],
// });

// const ShoppingList = mongoose.model("ShoppingList", ShoppingListSchema);

// /* ========== USER SCHEMA ========== */
// // Stores user information
// const UserSchema = new mongoose.Schema({
//   name: { type: String, required: true },
//   email: { type: String, required: true, unique: true },
//   shoppingPreferences: { type: Array, default: [] }, // Stores user preferences for smart suggestions
// });

// const User = mongoose.model("User", UserSchema);

// /* ========== ORDER HISTORY SCHEMA ========== */
// // Stores user's past purchases to help in recommendations
// const OrderSchema = new mongoose.Schema({
//   userId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
//   items: [
//     {
//       product: { type: mongoose.Schema.Types.ObjectId, ref: "Product" },
//       quantity: { type: Number, required: true },
//       priceAtPurchase: { type: Number, required: true },
//     },
//   ],
//   totalAmount: { type: Number, required: true },
//   orderDate: { type: Date, default: Date.now },
// });

// const Order = mongoose.model("Order", OrderSchema);

// /* ========== VOICE COMMAND SCHEMA ========== */
// // Logs user voice commands for NLP processing
// const VoiceCommandSchema = new mongoose.Schema({
//   userId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
//   command: { type: String, required: true },
//   interpretedAction: { type: String, required: true }, // Example: "Add to cart"
//   timestamp: { type: Date, default: Date.now },
// });

// const VoiceCommand = mongoose.model("VoiceCommand", VoiceCommandSchema);

// // Export all models for use in other parts of the app
// module.exports = {
//   Product,
//   CartItem,
//   ShoppingList,
//   User,
//   Order,
//   VoiceCommand,
// };


const mongoose = require("mongoose");

// Available Products Schema
const AvailableProductSchema = new mongoose.Schema({
    name: { type: String, required: true },
    category: { type: String },
    price: { type: Number, required: true },
    expiry: { type: Date },
});


const AvailableProduct = mongoose.model("AvailableProduct", AvailableProductSchema);

// Cart Schema
const CartSchema = new mongoose.Schema({
    product: { type: mongoose.Schema.Types.ObjectId, ref: "AvailableProduct", required: true },
    quantity: { type: Number, default: 1 },
});

const Cart = mongoose.model("Cart", CartSchema);

// Past Orders Schema
const PastOrdersSchema = new mongoose.Schema({
    product: { type: mongoose.Schema.Types.ObjectId, ref: "AvailableProduct", required: true },
    quantity: { type: Number, default: 1 },
    orderDate: { type: Date, default: Date.now },
});

const PastOrders = mongoose.model("PastOrders", PastOrdersSchema);

module.exports = { AvailableProduct, Cart, PastOrders };
