// // // const express = require("express");
// const cors = require("cors");
// // const dotenv = require("dotenv");
// // // const mongoose = require("mongoose");
// // // const shoppingRoutes = require("./routes");

// // dotenv.config();

// // // const app = express();
// // // app.use(express.json());
// app.use(cors({ origin: "http://localhost:5000/api/speech-to-text" }));

// // // mongoose
// // //   .connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
// // //   .then(() => console.log("MongoDB Connected"))
// // //   .catch((err) => console.log(err));

// // // app.use("/api", shoppingRoutes);

// // // const PORT = process.env.PORT || 5001;
// // // app.listen(PORT, () => {
// // //   console.log(`Server running on port ${PORT}`);
// // // });


// // const express = require("express");
// // const mongoose = require("mongoose");
// // const cors = require("cors");

// // const app = express();
// // app.use(express.json());
// // app.use(cors());

// // mongoose.connect(process.env.MONGO_URI, {
// //     useNewUrlParser: true,
// //     useUnifiedTopology: true,
// // });

// // const ItemSchema = new mongoose.Schema({ name: String });
// // const Item = mongoose.model("Item", ItemSchema);

// // app.get("/api/items", async (req, res) => {
// //     const items = await Item.find();
// //     res.json(items);
// // });

// // app.post("/api/items", async (req, res) => {
// //     const newItem = new Item({ name: req.body.name });
// //     await newItem.save();
// //     res.json(newItem);
// // });

// // app.listen(5001, () => console.log("Server running"));


require("dotenv").config();
const express = require("express");
const mongoose = require("mongoose");
const routes = require("./routes");

const app = express();
app.use(express.json());

mongoose
    .connect(process.env.MONGO_URI, {
        // useNewUrlParser: true,
        // useUnifiedTopology: true,
    })
    .then(() => console.log("MongoDB connected successfully"))
    .catch((err) => console.error("MongoDB connection error:", err));

app.use("/api", routes);

const PORT = process.env.PORT || 5001;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));


// const express = require("express");
// const cors = require("cors");

// const app = express();

// // ✅ Allow frontend (http://localhost:3000) to access backend
// app.use(cors({
//     origin: "http://localhost:3000",
//     methods: ["GET", "POST"],
//     allowedHeaders: ["Content-Type", "Authorization"]
// }));

// app.use(express.json()); // ✅ Allow JSON request body

// const PORT = process.env.PORT || 5001;
// app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
