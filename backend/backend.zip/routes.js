// const express = require("express");
// const ShoppingItem = require("./models");

// const router = express.Router();

// // Add item to the shopping list
// router.post("/add", async (req, res) => {
//   try {
//     const { name, category, quantity } = req.body;
//     const item = new ShoppingItem({ name, category, quantity });
//     await item.save();
//     res.status(201).json({ message: "Item added", item });
//   } catch (error) {
//     res.status(500).json({ error: error.message });
//   }
// });

// // Get all shopping list items
// router.get("/list", async (req, res) => {
//   try {
//     const items = await ShoppingItem.find();
//     res.json(items);
//   } catch (error) {
//     res.status(500).json({ error: error.message });
//   }
// });

// // Remove an item
// router.delete("/remove/:id", async (req, res) => {
//   try {
//     await ShoppingItem.findByIdAndDelete(req.params.id);
//     res.json({ message: "Item removed" });
//   } catch (error) {
//     res.status(500).json({ error: error.message });
//   }
// });

// module.exports = router;


// const express = require("express");
// const router = express.Router();
// const { AvailableProduct, Cart, ShoppingItem } = require("./models");
// const speechToText = require("./speechToText");

// // Get all available products
// router.get("/products", async (req, res) => {
//   try {
//     const products = await AvailableProduct.find();
//     res.json(products);
//   } catch (err) {
//     res.status(500).json({ error: err.message });
//   }
// });

// // Get shopping list
// router.get("/shopping-list", async (req, res) => {
//   try {
//     const items = await ShoppingItem.find();
//     res.json(items);
//   } catch (err) {
//     res.status(500).json({ error: err.message });
//   }
// });

// // Add item to shopping list
// router.post("/shopping-list", async (req, res) => {
//   try {
//     const { name, category, quantity } = req.body;
//     const newItem = new ShoppingItem({ name, category, quantity });
//     await newItem.save();
//     res.json(newItem);
//   } catch (err) {
//     res.status(500).json({ error: err.message });
//   }
// });

// // Remove item from shopping list
// router.delete("/shopping-list/:id", async (req, res) => {
//   try {
//     await ShoppingItem.findByIdAndDelete(req.params.id);
//     res.json({ message: "Item removed" });
//   } catch (err) {
//     res.status(500).json({ error: err.message });
//   }
// });

// // Speech-to-text processing route
// router.post("/speech-to-text", async (req, res) => {
//   try {
//     const { audioUrl } = req.body;
//     const text = await speechToText(audioUrl);
//     res.json({ recognizedText: text });
//   } catch (err) {
//     res.status(500).json({ error: err.message });
//   }
// });

// module.exports = router;



const express = require("express");
const router = express.Router();
const { AvailableProduct, Cart, PastOrders } = require("./models");

// Get all available products
router.get("/products", async (req, res) => {
    try {
        const products = await AvailableProduct.find();
        res.json(products);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Get all items in the cart
router.get("/cart", async (req, res) => {
    try {
        const cartItems = await Cart.find().populate("product");
        res.json(cartItems);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Get past orders
router.get("/past-orders", async (req, res) => {
    try {
        const orders = await PastOrders.find().populate("product");
        res.json(orders);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Add product to cart
router.post("/cart", async (req, res) => {
    try {
        const { productId, quantity } = req.body;
        const product = await AvailableProduct.findById(productId);

        if (!product) {
            return res.status(404).json({ error: "Product not found" });
        }

        const cartItem = new Cart({ product: productId, quantity });
        await cartItem.save();
        res.status(201).json({ message: "Product added to cart", cartItem });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Move cart product to past orders (checkout)
router.post("/checkout", async (req, res) => {
    try {
        const cartItems = await Cart.find();
        if (cartItems.length === 0) {
            return res.status(400).json({ error: "Cart is empty" });
        }

        // Move each cart item to past orders
        const pastOrders = cartItems.map(item => ({
            product: item.product,
            quantity: item.quantity
        }));

        await PastOrders.insertMany(pastOrders);
        await Cart.deleteMany(); // Clear cart after checkout

        res.status(201).json({ message: "Checkout successful", pastOrders });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Remove item from cart
router.delete("/cart/:id", async (req, res) => {
    try {
        await Cart.findByIdAndDelete(req.params.id);
        res.json({ message: "Item removed from cart" });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

module.exports = router;
