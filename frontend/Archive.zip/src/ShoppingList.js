// src/ShoppingList.js

import React from 'react';

const ShoppingList = ({ shoppingList, onRemoveItem }) => {
    return (
        <div className="shopping-list">
            <h3>Your Shopping List</h3>
            <ul>
                {shoppingList.map((item, index) => (
                    <li key={index}>
                        {item}
                        <button onClick={() => onRemoveItem(item)}>Remove</button>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default ShoppingList;
