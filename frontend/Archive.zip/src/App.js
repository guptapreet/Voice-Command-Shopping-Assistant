// // src/App.js

// import React, { useState } from 'react';
// import SpeechRecognition from './SpeechRecognition';
// import ShoppingList from './ShoppingList';
// import SmartSuggestions from './SmartSuggestions';
// import './App.css';

// function App() {
//   const [shoppingList, setShoppingList] = useState([]);

//   const handleAddItem = (item) => {
//     setShoppingList((prevList) => [...prevList, item]);
//   };

//   const handleRemoveItem = (item) => {
//     setShoppingList((prevList) => prevList.filter((i) => i !== item));
//   };

//   return (
//     <div className="App">
//       <h1>Voice Command Shopping Assistant</h1>
//       <SpeechRecognition 
//         onItemAdd={handleAddItem} 
//         onItemRemove={handleRemoveItem} 
//         shoppingList={shoppingList}
//       />
//       <ShoppingList shoppingList={shoppingList} onRemoveItem={handleRemoveItem} />
//       <SmartSuggestions shoppingList={shoppingList} />
//     </div>
//   );
// }

// export default App;


// src/App.js

import React, { useState } from 'react';
import SpeechRecognition from './SpeechRecognition';
import ShoppingList from './ShoppingList';
import SmartSuggestions from './SmartSuggestions';
import './App.css';

function App() {
  const [shoppingList, setShoppingList] = useState([]);

  const handleAddItem = (item) => {
    setShoppingList((prevList) => [...prevList, item]);
  };

  const handleRemoveItem = (item) => {
    setShoppingList((prevList) => prevList.filter((i) => i !== item));
  };

  return (
    <div className="App">
      <h1>Voice Command Shopping Assistant</h1>
      <SpeechRecognition 
        onItemAdd={handleAddItem} 
        onItemRemove={handleRemoveItem} 
        shoppingList={shoppingList}
      />
      <ShoppingList shoppingList={shoppingList} onRemoveItem={handleRemoveItem} />
      <SmartSuggestions shoppingList={shoppingList} />
    </div>
  );
}

export default App;
