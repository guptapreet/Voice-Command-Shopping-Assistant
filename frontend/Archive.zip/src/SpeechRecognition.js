// // // src/SpeechRecognition.js

// // import React, { useState } from 'react';

// // const SpeechRecognition = ({ onItemAdd, onItemRemove, shoppingList }) => {
// //   const [isListening, setIsListening] = useState(false);
// //   const [transcribedText, setTranscribedText] = useState('');

// //   const startListening = () => {
// //     const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
// //     const recognition = new SpeechRecognition();

// //     recognition.onstart = () => {
// //       setIsListening(true);
// //     };

// //     recognition.onresult = (event) => {
// //       const speechToText = event.results[0][0].transcript;
// //       setTranscribedText(speechToText);
// //       handleCommand(speechToText);
// //     };

// //     recognition.onerror = (event) => {
// //       console.error("Speech recognition error", event.error);
// //       setIsListening(false);
// //     };

// //     recognition.onend = () => {
// //       setIsListening(false);
// //     };

// //     recognition.start();
// //   };

// //   const handleCommand = (command) => {
// //     if (command.toLowerCase().includes('add')) {
// //       const item = command.split('add')[1].trim();
// //       onItemAdd(item);
// //     } else if (command.toLowerCase().includes('remove')) {
// //       const item = command.split('remove')[1].trim();
// //       onItemRemove(item);
// //     } else if (command.toLowerCase().includes('search')) {
// //       const query = command.split('search')[1].trim();
// //       alert(`Searching for ${query}`);
// //     } else {
// //       console.log('Command not recognized:', command);
// //     }
// //   };

// //   return (
// //     <div className="speech-recognition-container">
// //       <h1>Voice Shopping Assistant</h1>
// //       <button onClick={startListening}>
// //         {isListening ? 'Listening...' : 'Start Listening'}
// //       </button>
// //       <div>
// //         <h3>Transcribed Text:</h3>
// //         <p>{transcribedText}</p>
// //       </div>
// //       <div>
// //         <h3>Shopping List:</h3>
// //         <ul>
// //           {shoppingList.map((item, index) => (
// //             <li key={index}>{item}</li>
// //           ))}
// //         </ul>
// //       </div>
// //     </div>
// //   );
// // };

// // export default SpeechRecognition;



// import React, { useState } from "react";
// import axios from "axios";

// const SpeechRecognition = ({ onItemAdd, onItemRemove }) => {
//     const [isListening, setIsListening] = useState(false);
//     const [transcribedText, setTranscribedText] = useState("");

//     const startListening = () => {
//         const SpeechRecognition =
//             window.SpeechRecognition || window.webkitSpeechRecognition;
//         const recognition = new SpeechRecognition();

//         recognition.lang = "en-US"; // Change to "hi-IN", "fr-FR", etc. for multilingual support
//         recognition.continuous = false;

//         recognition.onstart = () => {
//             setIsListening(true);
//         };

//         recognition.onresult = (event) => {
//             const speechToText = event.results[0][0].transcript;
//             setTranscribedText(speechToText);
//             processCommand(speechToText);
//         };

//         recognition.onerror = (event) => {
//             console.error("Speech recognition error:", event.error);
//             setIsListening(false);
//         };

//         recognition.onend = () => {
//             setIsListening(false);
//         };

//         recognition.start();
//     };

//     const processCommand = async (command) => {
//         try {
//             const response = await axios.post(
//                 "https://api.openai.com/v1/chat/completions",
//                 {
//                     model: "gpt-3.5-turbo",
//                     messages: [{ role: "system", content: "You are a voice assistant. Extract the item and action from the command." },
//                     { role: "user", content: command }],
//                 },
//                 {
//                     headers: {
//                         Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
//                         "Content-Type": "application/json",
//                     },
//                 }
//             );

//             const aiResponse = response.data.choices[0].message.content.toLowerCase();

//             if (aiResponse.includes("add")) {
//                 const item = aiResponse.replace("add").trim();
//                 onItemAdd(item);
//             } else if (aiResponse.includes("remove")) {
//                 const item = aiResponse.replace("remove", "").trim();
//                 onItemRemove(item);
//             } else {
//                 console.log("Unrecognized command:", aiResponse);
//             }
//         } catch (error) {
//             console.error("Error processing command:", error);
//         }
//     };

//     return (
//         <div className="text-center mt-4">
//             <button
//                 onClick={startListening}
//                 className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition"
//             >
//                 {isListening ? "Listening..." : "Start Voice Command"}
//             </button>
//             <p className="mt-2 text-gray-600">{transcribedText}</p>
//         </div>
//     );
// };

// export default SpeechRecognition;



// src/SpeechRecognition.js

import React, { useState } from 'react';

const SpeechRecognition = ({ onItemAdd, onItemRemove, shoppingList }) => {
    const [isListening, setIsListening] = useState(false);
    const [transcribedText, setTranscribedText] = useState('');

    const startListening = () => {
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        const recognition = new SpeechRecognition();

        recognition.onstart = () => {
            setIsListening(true);
        };

        recognition.onresult = (event) => {
            const speechToText = event.results[0][0].transcript;
            setTranscribedText(speechToText);
            handleCommand(speechToText);
        };

        recognition.onerror = (event) => {
            console.error("Speech recognition error", event.error);
            setIsListening(false);
        };

        recognition.onend = () => {
            setIsListening(false);
        };

        recognition.start();
    };

    const handleCommand = (command) => {
        if (command.toLowerCase().includes('add')) {
            const item = command.split('add')[1].trim();
            onItemAdd(item);
        } else if (command.toLowerCase().includes('remove')) {
            const item = command.split('remove')[1].trim();
            onItemRemove(item);
        } else if (command.toLowerCase().includes('search')) {
            const query = command.split('search')[1].trim();
            alert(`Searching for ${query}`);
        } else {
            console.log('Command not recognized:', command);
        }
    };

    return (
        <div className="speech-recognition-container">
            <h1>Voice Shopping Assistant</h1>
            <button onClick={startListening}>
                {isListening ? 'Listening...' : 'Start Listening'}
            </button>
            <div>
                <h3>Transcribed Text:</h3>
                <p>{transcribedText}</p>
            </div>
            <div>
                <h3>Shopping List:</h3>
                <ul>
                    {shoppingList.map((item, index) => (
                        <li key={index}>{item}</li>
                    ))}
                </ul>
            </div>
        </div>
    );
};

export default SpeechRecognition;
